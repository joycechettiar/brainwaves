<?php
$con=mysqli_connect('us-cdbr-iron-east-03.cleardb.net', 'bda2bbcb6d0403', 'e878b928', 'heroku_ac9d2ff54218652');

if (mysqli_connect_errno())
  {
  echo "Failed to connect to DB: " . mysqli_connect_error();
  }

  $sql="SELECT freq_value,timer_completed,time_stamp FROM usertimer WHERE timer_completed='True'";
  $output = '';
  $count = 0 ;
if ($result=mysqli_query($con,$sql))
  {
   $output .= '
  <table border="1">
   <tr>
      <th>freq_value</th>
      <th>timer_completed</th>
      <th>time_stamp</th>
    </tr>';
    echo $output;
  while ($row=mysqli_fetch_assoc($result))
    {
        print "<tr> <td>";
        echo $row['freq_value'];
        print "</td> <td>";
        echo $row['timer_completed'];
        print "</td> <td>";
        echo $row['time_stamp'];
        print "</td> </tr>";

     }
}
     $result1 = mysqli_query($con,"select count(1) FROM usertimer WHERE timer_completed='True' ");
     $row1 = mysqli_fetch_array($result1);

     $total1 = $row1['freq_value'];

     $q1 = mysqli_query($con,"SELECT freq_value FROM usertimer WHERE timer_completed='True'");
     $a1 = array();
     while($row12 = mysqli_fetch_assoc($q1))
     {
       $a1[] = $row12;
     }

     for($i = 0; $i < $total1;$i++)
     {
      if($a1 >= 5.0 || $a1 <= 9.0)
      $count = $count + 1;
     }
     if($count>3)
     {
     echo "\n";
     echo "Consult a doctor";
      }

mysqli_close($con);
?>
