<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

  $username = $_POST['user_name'];
  $timer_value = $_POST['timer_value'];
  $timer_remaining = $_POST['timer_remaining'];
  $timer_completed = $_POST['timer_completed'];
  echo $timer_completed;
  $freq_value = $_POST['freq_value'];

  require_once 'connect.php';

  $Sql_Query = "INSERT INTO usertimer(user_name, timer_value, timer_remaining, timer_completed, time_stamp, freq_value) VALUES ('$username','$timer_value', '$timer_remaining', '$timer_completed', CURRENT_TIMESTAMP(), '$freq_value')";

  if (mysqli_query($conn,$Sql_Query)) {
    $result["success"] = "1";
    $result["message"] = "success";

    echo json_encode($result);
  }
  else{
    $result["success"] = "0";
    $result["message"] = "error";

    echo json_encode($result);
  }
  mysqli_close($conn);
}

?>
