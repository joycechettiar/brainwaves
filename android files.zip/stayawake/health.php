<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

  $user_name = $_POST['user_name'];
  $user_slept = $_POST['user_slept'];
  $work_hours = $_POST['work_hours'];
  $timer_completed = $_POST['timer_completed'];
  $freq_value = $_POST['freq_value'];

  require_once 'connect.php';

  $Sql_Query = "INSERT INTO usertimer(user_name, user_slept, work_hours, timer_completed, freq_value) VALUES ('$username','$user_slept', '$work_hours', '$timer_completed', '$freq_value')";

  if (mysqli_query($conn,$Sql_Query)) {
    $result["success"] = "1";
    $result["message"] = "success";

    echo json_encode($result);
  }
  else{
    $result["success"] = "0";
    $result["message"] = "error";

    echo json_encode($result);
  }
  mysqli_close($conn);
}

?>
