<?php

$conn = mysqli_connect('us-cdbr-iron-east-03.cleardb.net', 'bda2bbcb6d0403', 'e878b928', 'heroku_ac9d2ff54218652');

 ?>
