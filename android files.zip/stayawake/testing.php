<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

  $valuess = $_POST['valuess'];

  require_once 'connect.php';

  $Sql_Query = "INSERT INTO frquency1(values1) VALUES ('$valuess')";

  if(mysqli_query($conn,$Sql_Query)){
    $result["success"] = "1";
    $result["message"] = "success";

    echo json_encode($result);
  }
  else{
    $result["success"] = "0";
    $result["message"] = "error";

    echo json_encode($result);
  }
  mysqli_close($conn);
}
?>
