<?php


if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $usersname = $_POST['users_name'];
    $username = $_POST['user_name'];
    $password = $_POST['user_password'];
    $gender = $_POST['user_gender'];
    $age = $_POST['user_age'];

    $password1 = password_hash($password, PASSWORD_DEFAULT);

    require_once 'connect.php';

    $sql = "INSERT INTO userData(users_name, user_name, user_password, user_gender, user_age) VALUES ('$usersname', '$username', '$password1', '$gender', $age)";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>
