<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

$query = "SELECT * FROM frquency1 ORDER BY freqid DESC LIMIT 1";

require_once 'connect.php';
$result = mysqli_query($conn, $query);

// if ( mysqli_query($conn, $sql) ) {
//     $result["success"] = "1";
//     $result["message"] = "success";
//
//     echo json_encode($result);
//     mysqli_close($conn);
//
// } else {
//
//     $result["success"] = "0";
//     $result["message"] = "error";
//
//     echo json_encode($result);
//     mysqli_close($conn);
// }

if( mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $response['value1'] = $row['values1'];
    }
}

echo json_encode($response);

// header('Content-Type: application/json');
// echo json_encode(array("value1"=>$response));
// mysqli_close($conn);
}
?>
