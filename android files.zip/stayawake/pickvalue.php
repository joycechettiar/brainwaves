<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

$username = $_POST['user_name'];

$query = "SELECT * FROM usertimer WHERE user_name='$username' ORDER BY timer_id DESC LIMIT 1";

require_once 'connect.php';
$result = mysqli_query($conn, $query);

if( mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $response['freq_value'] = $row['freq_value'];
    }
}

echo json_encode($response);
}
?>
