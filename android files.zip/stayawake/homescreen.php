


<?php

  $username = $_POST["user_name"];



   require_once 'connect.php';
   $query = "SELECT timer_value,timer_remaining,timer_completed FROM usertimer WHERE user_name='$username'";

   $logarray=[];
   $result = mysqli_query($conn, $query);


if(mysqli_num_rows($result)>0)
{
  while ($row=mysqli_fetch_assoc($result)) {

    $logarray[]=$row;
  }
}
die(json_encode($logarray));


   mysqli_close($conn);

?>
