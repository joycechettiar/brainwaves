<?php
        $connect = mysqli_connect("us-cdbr-iron-east-03.cleardb.net","bda2bbcb6d0403","e878b928");
		mysqli_select_db($connect,"heroku_ac9d2ff54218652") or die("<h3>Couldn't find database</h3>");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

//create array for JSON response
$response = array();

//check field from ard
if (isset($_GET['device_id']) && isset($_GET['eeg_freq'])) {
	$device_id = $_GET['device_id'];
	$eeg_freq = $_GET['eeg_freq'];


	//sql query
	$result = mysqli_query($connect,"INSERT INTO freq(device_id,eeg_freq,time_stamp) VALUES('$device_id','$eeg_freq', CURRENT_TIMESTAMP())");

	if($result){
		$response["success"] = 1;
		$response["message"] = "Data uploaded successfully";

		echo json_encode($response);
	}
	else {
		$response["success"] = 0;
		$response["message"] = "Something is wrong";

		echo json_encode($response);
	}
}
	else {
		$response["success"] = 0;
		$response["message"] = "Parameter missing";

		echo json_encode($response);
	}

?>
