package com.levirs.example.bottomnavigationbar;

class Timers {

    private String timer_value;
    private String timer_completed;

    public String getTimer_value() {
        return this.timer_value;
    }

    public void setTimer_value(String timer_value) {
        this.timer_value = timer_value;
    }

    public String getTimer_completed() {
        return this.timer_completed;
    }

    public void setTimer_completed(String timer_completed) {
        if ("True".equals(timer_completed)) {
            timer_completed = "Completed";
        } else {
            timer_completed = "Not Completed";
        }
        this.timer_completed = timer_completed;
    }
}
