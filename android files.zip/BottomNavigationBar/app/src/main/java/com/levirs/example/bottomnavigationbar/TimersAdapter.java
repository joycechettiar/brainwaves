package com.levirs.example.bottomnavigationbar;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class TimersAdapter extends RecyclerView.Adapter<TimersAdapter.TimerViewHolder> {

    private Context context;
    private List<Timers> timersList;
    Timers getTimerlist;

    public TimersAdapter(Context context, List<Timers> timersList) {
        this.context = context;
        this.timersList = timersList;
    }

    @NonNull
    @Override
    public TimerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.list_adapter_view, null);
        TimerViewHolder holder = new TimerViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull TimerViewHolder timerViewHolder, int i) {
        getTimerlist = timersList.get(i);

        timerViewHolder.timerValue.setText(getTimerlist.getTimer_value());
        timerViewHolder.timerCompleted.setText(getTimerlist.getTimer_completed());

        timerViewHolder.gt=getTimerlist;
    }

    @Override
    public int getItemCount() {
        return timersList.size();
    }

    public class TimerViewHolder extends RecyclerView.ViewHolder {

        TextView timerValue, timerCompleted;
        Timers gt;

        public TimerViewHolder(@NonNull View itemView) {
            super(itemView);

            timerValue = itemView.findViewById(R.id.timer_value);
            timerCompleted = itemView.findViewById(R.id.timer_completed);

        }
    }

}

