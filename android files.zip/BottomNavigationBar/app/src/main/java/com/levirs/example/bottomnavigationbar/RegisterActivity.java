package com.levirs.example.bottomnavigationbar;

import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.widget.Toast.makeText;

public class RegisterActivity extends AppCompatActivity {

    private EditText et_username, et_password, et_age, et_usersname;
    private TextView loggedin_tv, login_tv;
    private RadioGroup radiobtn_group;
    private RadioButton radioSexButton;
    private ProgressBar loading;
    private Button registerBtn;
    private static String URL_REGIST = "https://fathomless-headland-57541.herokuapp.com/register.php";
    private long mLastClickTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        et_usersname = findViewById(R.id.et_usersname);
        et_age = findViewById(R.id.age_et);
        loggedin_tv = findViewById(R.id.loggedin_tv);
        login_tv = findViewById(R.id.login_tv);
        registerBtn = findViewById(R.id.register_btn);
        loading = findViewById(R.id.loading);
        radiobtn_group = findViewById(R.id.radiobtn_group);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                // get selected radio button from radioGroup
                int selectedId = radiobtn_group.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                radioSexButton = (RadioButton) findViewById(selectedId);
                String users_nameC = et_usersname.getText().toString().trim();
                String user_nameC = et_username.getText().toString().trim();
                String user_passwordC = et_password.getText().toString().trim();
                String user_ageC = et_age.getText().toString().trim();
                if(!user_nameC.isEmpty() || !users_nameC.isEmpty() || !user_ageC.isEmpty() || !user_passwordC.isEmpty()) {
                    Regist();
                } else {
                    et_age.setError("Please insert age");
                    et_password.setError("Please insert password");
                    et_username.setError("Please insert username");
                    et_usersname.setError("Please enter your name");
                    Toast.makeText(RegisterActivity.this, "PLEASE ENTER INPUTS", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    private void Regist() {
        loading.setVisibility(View.VISIBLE);
        registerBtn.setVisibility(View.GONE);
        login_tv.setVisibility(View.GONE);
        loggedin_tv.setVisibility(View.GONE);

        final String users_name = this.et_usersname.getText().toString().trim();
        final String user_name = this.et_username.getText().toString().trim();
        final String user_password = this.et_password.getText().toString().trim();
        final String user_age = this.et_age.getText().toString().trim();
        final String user_gender = this.radioSexButton.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGIST,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");

                            System.out.println(success);
                            if (success.equals("1")){
                                makeText(RegisterActivity.this, "Register success", Toast.LENGTH_LONG).show();
                                loading.setVisibility(View.GONE);
                                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                                startActivity(intent);
                            } else {
                                et_username.setError("Username already exist");
                                Toast.makeText(RegisterActivity.this, "Username already exist", Toast.LENGTH_LONG).show();
                                loading.setVisibility(View.GONE);
                                registerBtn.setVisibility(View.VISIBLE);
                                login_tv.setVisibility(View.VISIBLE);
                                loggedin_tv.setVisibility(View.VISIBLE);
                            }

                            Log.d("response",""+response);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            makeText(RegisterActivity.this, "error: " + e.toString(), Toast.LENGTH_LONG).show();
                            loading.setVisibility(View.GONE);
                            registerBtn.setVisibility(View.VISIBLE);
                            System.out.println("in e: "+ e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        makeText(RegisterActivity.this, "error: " + error.toString(), Toast.LENGTH_LONG).show();
                        loading.setVisibility(View.GONE);
                        registerBtn.setVisibility(View.VISIBLE);

                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("users_name", users_name);
                params.put("user_name", user_name);
                params.put("user_password", user_password);
                params.put("user_gender", user_gender);
                params.put("user_age", user_age);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void OnLogin(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

}
