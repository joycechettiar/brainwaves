package com.levirs.example.bottomnavigationbar;


import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;


/**
 * A simple {@link Fragment} subclass.
 */
public class TimerFragment extends Fragment {

    private Button startBtn;
    private Button doneBtn, clearBtn, stopBtn, stopMusic, checkValueBtn;
    private CountDownTimer countDownTimer;
    public boolean mTimerRunning;
    public String timerCompleted, getSelectedSleepValue;
    public Spinner hours_spinner, minutes_spinner;
    public Button setTimerBtn;
    private TextView countDownTV, checkedValuesTV, fetchFreq, fetchedValue;
    private EditText workingHoursET;
    private long timeInMillis;
    private int numberMin, numberHours;
    private static String URL_TIMER = "https://fathomless-headland-57541.herokuapp.com/timer.php";
    private static String URL_CHECK = "https://fathomless-headland-57541.herokuapp.com/valuetest.php";
    private static String URL_FREQ = "https://fathomless-headland-57541.herokuapp.com/pickvalue.php";
    String dataShare, musername, remainingTimer, freqValue, outputVariable;
    SessionManager sessionManager;
    private ProgressBar timer_uploading;
    private long mLastClickTime = 0;
    MediaPlayer alarm;
    private RequestQueue mQueue;
    private RadioGroup sleptRadioBtn;
    private RadioButton yesNoRadioBtn;
    public int getWorkingHours = 0;
    public float checkFreq;
    int loop=1;


    public TimerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sessionManager = new SessionManager(getContext());
        sessionManager.checkLogin();

        HashMap<String, String> user = sessionManager.getUserDetails();
        musername = user.get(sessionManager.USERNAME);

        hours_spinner = getView().findViewById(R.id.hours_spinner);
        minutes_spinner = getView().findViewById(R.id.min_spinner);
        setTimerBtn = getView().findViewById(R.id.settimer_btn);

        startBtn = getView().findViewById(R.id.start_btn);
        startBtn.setEnabled(false);
        stopBtn = getView().findViewById(R.id.stop_btn);
        stopBtn.setEnabled(false);
        doneBtn = getView().findViewById(R.id.done_btn);
        doneBtn.setEnabled(false);
        clearBtn = getView().findViewById(R.id.clear_btn);
        checkValueBtn = getView().findViewById(R.id.check_value_btn);
        stopMusic = getView().findViewById(R.id.music_stop);
        countDownTV = getView().findViewById(R.id.countdown_textview_main);
        checkedValuesTV = getView().findViewById(R.id.checked_values_tv);
        sleptRadioBtn = getView().findViewById(R.id.radiogrp_slept);
        timer_uploading = getView().findViewById(R.id.timer_uploading);
        workingHoursET = getView().findViewById(R.id.users_working_hours_et);
        fetchFreq = getView().findViewById(R.id.fetch_tv);
        fetchedValue = getView().findViewById(R.id.wavefreq_tv);


        mTimerRunning = false;

        String[] hours = getResources().getStringArray(R.array.hours);
        String[] minutes = getResources().getStringArray(R.array.minutes);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this.getActivity(), android.R.layout.simple_spinner_dropdown_item, hours);
        hours_spinner.setAdapter(adapter);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this.getActivity(), android.R.layout.simple_spinner_dropdown_item, minutes);
        minutes_spinner.setAdapter(adapter1);


        /**************
        SETTING THE TEXT FROM UPPER LINEARLAYOUT TO BELOW LINEARLAYOUT
                *************/
        setTimerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String spinner_hour = hours_spinner.getSelectedItem().toString();
                String spinner_minutes = minutes_spinner.getSelectedItem().toString();

                countDownTV.setText("0" + spinner_hour + ":" + spinner_minutes + ":00");
                dataShare = countDownTV.getText().toString();

                numberMin = Integer.parseInt(spinner_minutes);
                numberHours = Integer.parseInt(spinner_hour);

                timeInMillis = TimeUnit.SECONDS.toMillis(TimeUnit.HOURS.toSeconds(numberHours) + TimeUnit.MINUTES.toSeconds(numberMin));

                startBtn.setEnabled(true);

                timerCompleted = "False";
            }
        });

        mQueue = Volley.newRequestQueue(getActivity());

        /*************
        STARTING THE TIMER
                ************/
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopBtn.setEnabled(true);
                startBtn.setEnabled(false);
                setTimerBtn.setEnabled(false);
                clearBtn.setEnabled(false);
                checkValueBtn.setEnabled(false);
                doneBtn.setEnabled(false);

                countDownTimer = new CountDownTimer( timeInMillis ,1000) {

                    @Override
                    public void onTick(long l) {
                        timeInMillis = l;
                        //System.out.println(timeInMillis);
                        System.out.println("on tick");
                        updateCountDownText();

                        if(loop == 1) {

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    // TODO Auto-generated method stub
                                    readingValue();
                                }
                            }, 1000);

                        }
                    }

                    @Override
                    public void onFinish() {
                        startBtn.setEnabled(true);
                        stopBtn.setEnabled(false);
                        doneBtn.setEnabled(true);
                        timerCompleted = "True";
                        remainingTimer = "00:00:00";
                        ringAlarm();
                    }

                }.start();

                mTimerRunning = true;
            }
        });

        /*************
        STOP THE TIMER
                ***********/
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                countDownTimer.cancel();
                mTimerRunning = false;
                startBtn.setEnabled(true);
                stopBtn.setEnabled(false);
                doneBtn.setEnabled(true);
                clearBtn.setEnabled(true);
                setTimerBtn.setEnabled(true);

                remainingTimer = countDownTV.getText().toString();
            }
        });

        doneBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                startBtn.setEnabled(false);
                stopBtn.setEnabled(false);
                setTimerBtn.setEnabled(false);
                doneBtn.setEnabled(false);
                clearBtn.setEnabled(false);

                insertData();
            }
        });


        /*************
        CLEAR THE FIELDS OF CountDownTimer
                ***********/
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startBtn.setEnabled(false);
                stopBtn.setEnabled(false);
                doneBtn.setEnabled(false);
                setTimerBtn.setEnabled(true);
                countDownTV.setText("00:00:00");
                timer_uploading.setVisibility(View.GONE);
            }
        });


        /**************
        CHECK PANDEY IF LOOP
                ************/

        int selectedId = sleptRadioBtn.getCheckedRadioButtonId();
        yesNoRadioBtn = getView().findViewById(selectedId);

        fetchFreq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickValueFreq();

            }
        });

        checkValueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Float checkPrevFreq = checkFreq;
                getWorkingHours = Integer.parseInt(workingHoursET.getText().toString());
                getSelectedSleepValue = yesNoRadioBtn.getText().toString().trim();
                    Toast.makeText(getActivity(), checkFreq+"", Toast.LENGTH_LONG).show();
                    if (getWorkingHours >= 8 && getSelectedSleepValue.equals("No") && checkPrevFreq >= 13.0) {
                        outputVariable = "Sleep loss visit Doctor";
                    } else if (getWorkingHours > 8 && getSelectedSleepValue.equals("No") && checkPrevFreq > 13.0) {
                        outputVariable = "No sleep loss";
                    } else if (getWorkingHours < 8 && getSelectedSleepValue.equals("No") && (checkPrevFreq <= 9 && checkPrevFreq >= 5)) {
                        outputVariable = "No sleep loss";
                    } else if (getWorkingHours < 8 && getSelectedSleepValue.equals("No") && (checkPrevFreq <= 9 && checkPrevFreq >= 5)){
                        outputVariable = "No sleep loss";
                    } else {
                        outputVariable = "No sleep loss";
                    }
                    checkedValuesTV.setText(outputVariable);
                    //healthInsert();
            }
        });

        stopMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopMusic.setVisibility(View.GONE);
                alarm.stop();
                alarm.release();
                loop = 1;
            }
        });

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_timer, container, false);
    }


    /**************
    UPDATE COUNTDOWN TEXTVIEW
    *************/
    private void updateCountDownText() {
        int hoursInt = (int) (timeInMillis / 1000) / (60*60);
        int minutesInt = (int) ((timeInMillis / 1000) / 60) % 60;
        int secondsInt = (int) (timeInMillis / 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", hoursInt,minutesInt, secondsInt);

        countDownTV.setText(timeLeftFormatted);
    }

    /****************
     *
     *
     * FETCH FROM FREQ TABLE
     ******************/
    private void readingValue() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_CHECK,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            String value1 = jsonObject.getString("value1");

                            System.out.println(value1);
                            freqValue = value1;
                            if(Float.parseFloat(value1) <= 9 && Float.parseFloat(value1) >= 5) {
                                //loop = 0;
                                ringAlarm();
                            } else {
                                loop = 1;
                            }

                        } catch (JSONException e) {
                            //System.out.println(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "error out", Toast.LENGTH_LONG).show();

                    }
                }
        );
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

    /***************
     *
     *
     * ALARM RINGING CODE

    ***************/
    private void ringAlarm() {
        alarm = MediaPlayer.create(getContext(), R.raw.bellringing);
        stopMusic.setVisibility(View.VISIBLE);

            alarm.start();

    }

    /****************
    INSERT DATA TO TIMERS TABLE
    ***************/
    private void insertData(){
        final String user_name = this.musername;
        final String timer_value = this.dataShare;
        final String timer_completed = this.timerCompleted;
        final String timer_remaining = this.remainingTimer;
        final String freq_value = freqValue;

        System.out.println(timer_remaining);
        System.out.println(timer_completed);

        timer_uploading.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_TIMER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            System.out.println(success);

                            if (success.equals("1")) {
                                Toast.makeText(getActivity(), "uploaded", Toast.LENGTH_LONG).show();
                                timer_uploading.setVisibility(View.GONE);
                                startBtn.setEnabled(true);
                                clearBtn.setEnabled(true);
                                countDownTV.setText("00:00:00");
                                setTimerBtn.setEnabled(true);
                            } else {
                                Toast.makeText(getActivity(), "Failed\nSuccess = 0", Toast.LENGTH_LONG).show();
                                timer_uploading.setVisibility(View.GONE);
                                clearBtn.setEnabled(true);
                                doneBtn.setEnabled(true);
                            }
                            Log.d("response",""+response);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            System.out.println(e);
                            timer_uploading.setVisibility(View.GONE);
                            clearBtn.setEnabled(true);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "error: " + error.toString(), Toast.LENGTH_LONG).show();
                        timer_uploading.setVisibility(View.GONE);
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_name", user_name);
                params.put("timer_value", timer_value);
                params.put("timer_completed", timer_completed);
                params.put("timer_remaining", timer_remaining);
                params.put("freq_value", freq_value);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);

    }

    public void pickValueFreq() {

        final String user_name = this.musername;

        System.out.println("here");
        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, URL_FREQ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println("now here");
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            String value2 = jsonObject.getString("freq_value");

                            System.out.println(value2);
                            checkFreq = Float.parseFloat(value2);
                            fetchedValue.setText(value2);

                        } catch (JSONException e) {
                            System.out.println(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "error out", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_name", user_name);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest2);
    }

    public void healthInsert(){
        final String user_name = this.musername;
        final String user_slept = this.getSelectedSleepValue;
        final String working_hours = String.valueOf(this.getWorkingHours);
        final String timer_completed = this.timerCompleted;
        final String freq_value = freqValue;

        timer_uploading.setVisibility(View.VISIBLE);

        StringRequest stringRequest3 = new StringRequest(Request.Method.POST, URL_TIMER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            System.out.println(success);

                            if (success.equals("1")) {
                                Toast.makeText(getActivity(), "uploaded", Toast.LENGTH_LONG).show();
                                timer_uploading.setVisibility(View.GONE);
                                startBtn.setEnabled(true);
                                clearBtn.setEnabled(true);
                                countDownTV.setText("00:00:00");
                                setTimerBtn.setEnabled(true);
                            } else {
                                Toast.makeText(getActivity(), "Failed\nSuccess = 0", Toast.LENGTH_LONG).show();
                                timer_uploading.setVisibility(View.GONE);
                                clearBtn.setEnabled(true);
                                doneBtn.setEnabled(true);
                            }
                            Log.d("response",""+response);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            System.out.println(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "error: " + error.toString(), Toast.LENGTH_LONG).show();
                        timer_uploading.setVisibility(View.GONE);
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_name", user_name);
                params.put("user_slept", user_slept);
                params.put("working_hours", working_hours);
                params.put("timer_completed", timer_completed);
                params.put("freq_value", freq_value);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest3);
    }
}

