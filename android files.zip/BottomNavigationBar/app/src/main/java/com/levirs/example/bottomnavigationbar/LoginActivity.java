package com.levirs.example.bottomnavigationbar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private TextView password_tv, username_tv, register_tv, notYetMember_tv;
    private EditText password_et, username_et;
    private Button login_btn;
    private ProgressBar loading;
    private static String URL_LOGIN="https://fathomless-headland-57541.herokuapp.com/login.php";
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(this);

        loading = findViewById(R.id.loading);
        username_et = findViewById(R.id.username_et);
        password_et = findViewById(R.id.password_et);
        login_btn = findViewById(R.id.login_btn);
        register_tv = findViewById(R.id.register_tv);
        notYetMember_tv = findViewById(R.id.not_signup_tv);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mUsername = username_et.getText().toString().trim();
                String mPassword = password_et.getText().toString().trim();

                if (!mUsername.isEmpty() || !mPassword.isEmpty() ) {
                    Login(mUsername,mPassword);
                } else {
                    username_et.setError("Please insert username");
                    password_et.setError("Please insert password");
                    Toast.makeText(LoginActivity.this, "ENTER INPUTS",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void Login(final String username, final String password) {

        loading.setVisibility(View.VISIBLE);
        login_btn.setVisibility(View.GONE);
        notYetMember_tv.setVisibility(View.GONE);
        register_tv.setVisibility(View.GONE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("login");
                            System.out.println(success);
                            if (success.equals("1")){
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject object = jsonArray.getJSONObject(i);

                                    String usersname = object.getString("users_name").trim();
                                    String username = object.getString("user_name").trim();
                                    String age = object.getString("user_age").trim();
                                    String gender = object.getString("user_gender").trim();

                                    //sessionManager.createSession(usersname, username);
                                    sessionManager.createSession(usersname, username, age, gender);

                                    Toast.makeText(LoginActivity.this, "logged in " + username + "\nyour name: " + usersname, Toast.LENGTH_LONG).show();

                                    loading.setVisibility(View.GONE);
                                    login_btn.setVisibility(View.VISIBLE);
                                    notYetMember_tv.setVisibility(View.VISIBLE);
                                    register_tv.setVisibility(View.VISIBLE);

                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    startActivity(intent);
                                }
                            } else {
                                username_et.setError("Invalid");
                                password_et.setError("Invalid");
                                Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_LONG).show();
                                loading.setVisibility(View.GONE);
                                login_btn.setVisibility(View.VISIBLE);
                                notYetMember_tv.setVisibility(View.VISIBLE);
                                register_tv.setVisibility(View.VISIBLE);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            loading.setVisibility(View.GONE);
                            login_btn.setVisibility(View.VISIBLE);
                            notYetMember_tv.setVisibility(View.VISIBLE);
                            register_tv.setVisibility(View.VISIBLE);
                            Toast.makeText(LoginActivity.this, "Error" + e.toString(), Toast.LENGTH_LONG).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.setVisibility(View.GONE);
                        login_btn.setVisibility(View.VISIBLE);
                        notYetMember_tv.setVisibility(View.VISIBLE);
                        register_tv.setVisibility(View.VISIBLE);
                        Toast.makeText(LoginActivity.this, "Error" + error.toString(), Toast.LENGTH_LONG).show();
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("user_name", username);
                params.put("user_password", password);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void onRegister(View view){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }


}
