package com.levirs.example.bottomnavigationbar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment{

    SessionManager sessionManager;
    String mUsername;
    RecyclerView timerHistoryRecycler;
    TimersAdapter timersAdapter;
    List<Timers> timersList;

    private TextView usersname;
    private static String URL="https://fathomless-headland-57541.herokuapp.com/homescreen.php";

    public HomeFragment() {
        // Required empty public constructor
    }
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_home, container, false);

        sessionManager = new SessionManager(getContext());
        sessionManager.checkLogin();

        usersname = view.findViewById(R.id.name_tv);

        timerHistoryRecycler = view.findViewById(R.id.recyclerView_timer);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        timerHistoryRecycler.setLayoutManager(llm);
        timerHistoryRecycler.setHasFixedSize(true);

        timersList = new ArrayList<>();

        HashMap<String, String> user = sessionManager.getUserDetails();
        String mName = user.get(sessionManager.NAME);
        mUsername = user.get(sessionManager.USERNAME);

        usersname.setText(mName);

        loadHistory();
        return  view;
    }

    public void loadHistory() {

        final String user_name = mUsername;

        //JSONObject parameters = new JSONObject(params);
        System.out.println(user_name);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("responsrespons",""+response);
                        try {
                             JSONArray array = new JSONArray(response);

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject timerObject = array.getJSONObject(i);
                                Timers timertemp = new Timers();

                                System.out.println(timerObject);
                                timertemp.setTimer_value(timerObject.getString("timer_value"));
                                timertemp.setTimer_completed(timerObject.getString("timer_completed"));
                                //timertemp.setRemaining_timer(timerObject.getString("timer_remaining"));
                                timersList.add(timertemp);
                                System.out.println(timersList);
                            }
                            timersAdapter = new TimersAdapter(getActivity(), timersList);
                            timerHistoryRecycler.setAdapter(timersAdapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
                Log.d("errorerror",""+error);
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_name", mUsername);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);

    }

}
