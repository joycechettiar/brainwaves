package com.levirs.example.bottomnavigationbar;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class AccountFragment extends Fragment {

    private TextView mName_tv, mUsername_tv, mAge_tv, mGender_tv;
    private Button logout_btn;
    SessionManager sessionManager;
    String mUsername, mAge, mGender;
    private static String URL_ACC = "https://fathomless-headland-57541.herokuapp.com/userdetails.php";

    public AccountFragment() {
        // Required empty public constructor
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mName_tv = getView().findViewById(R.id.mName_tv);
        mUsername_tv = getView().findViewById(R.id.mUsername_tv);
        mGender_tv = getView().findViewById(R.id.mGender_tv);
        mAge_tv = getView().findViewById(R.id.mAge_tv);
        logout_btn = getView().findViewById(R.id.logout_btn1);

        sessionManager = new SessionManager(getContext());
        sessionManager.checkLogin();

        HashMap<String, String> user = sessionManager.getUserDetails();
        String mName = user.get(sessionManager.NAME);
        mUsername = user.get(sessionManager.USERNAME);
        //String mAge = user.get(sessionManager.)

        mName_tv.setText(mName);
        mUsername_tv.setText(mUsername);

        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sessionManager.logout();
            }
        });

        gettingValue();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    public void gettingValue() {

        final String user_name = this.mUsername;

        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, URL_ACC,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("login");

                            System.out.println(success);
                            if (success.equals("1")){
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject object = jsonArray.getJSONObject(i);

                                    mGender = object.getString("user_gender").trim();
                                    mAge = object.getString("user_age").trim();

                                    Toast.makeText(getActivity(), "loaded", Toast.LENGTH_LONG).show();
                                }
                            }

                            System.out.println(mAge);
                            System.out.println(mGender);

                            mAge_tv.setText(mAge);
                            mGender_tv.setText(mGender);

                        } catch (JSONException e) {
                            System.out.println(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "error out", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_name", user_name);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest2);
    }

}
